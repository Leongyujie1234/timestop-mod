package com.timestop.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_2394;
import net.minecraft.class_4081;
import org.jetbrains.annotations.Nullable;

/**
 * A completely invisible status effect that serves as a marker for the
 * movement-packet mixin. When this effect is active on a player, the
 * server-side mixin will silently drop all player-move packets, effectively
 * freezing the player in place from the server's perspective.
 *
 * <p>Key design choices:
 * <ul>
 *   <li>{@link class_4081#field_18273} — neither beneficial nor harmful,
 *       so it does not influence mob AI or entity attribute calculations.</li>
 *   <li>{@link #method_58146(class_1293)} returns {@code null} —
 *       no ambient particles are ever spawned, regardless of the effect
 *       instance's {@code showParticles} flag.</li>
 *   <li>{@link #method_5561()} returns {@code false} — the effect persists over
 *       time and must be explicitly removed or expire.</li>
 *   <li>The colour value {@code 0xFFFFFF} is a no-op placeholder; because the
 *       effect is never rendered, the colour is irrelevant.</li>
 * </ul>
 *
 * <p><b>Icon visibility</b>: In Minecraft 1.21.5, the icon visibility flag
 * ({@code showIcon}) is a per-instance property on {@link class_1293},
 * not a property of the effect type itself. The Scarpet command
 * {@code effect give @a[tag=!immune] timestop:stun infinite 0 true} sets
 * {@code hideParticles=true}, which in vanilla also sets {@code showIcon=false},
 * making the effect fully invisible to the affected player.
 */
public class StunEffect extends class_1291 {

    /**
     * Constructs the stun effect as a NEUTRAL, colourless effect.
     * The colour (0xFFFFFF) is a harmless placeholder — it will never be
     * rendered to the client because both icon and particles are suppressed.
     */
    public StunEffect() {
        super(class_4081.field_18273, 0xFFFFFF);
    }

    /**
     * Suppresses all ambient particles for this effect.
     * Returns {@code null} so that no particle effect is ever created,
     * regardless of the effect instance's configuration.
     *
     * @param instance the active effect instance (unused)
     * @return {@code null} — no particles
     */
    @Override
    @Nullable
    public class_2394 method_58146(class_1293 instance) {
        return null;
    }

    /**
     * Indicates that this is a duration-based (non-instant) effect.
     * The Scarpet command uses {@code infinite} duration, which relies on
     * the effect being non-instant to persist across ticks.
     *
     * @return {@code false} always
     */
    @Override
    public boolean method_5561() {
        return false;
    }
}
