package com.timestop;

import com.timestop.effect.StunEffect;
import net.minecraft.class_1291;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main entry point for the TimeStop Fabric mod.
 *
 * <p>This mod registers a single invisible status effect ({@code timestop:stun})
 * and uses a Mixin to intercept player movement packets on the server side.
 * When the stun effect is active on a player, the server silently drops all
 * movement packets from that player, effectively freezing them in place
 * without any visual feedback (no icon, no particles).
 *
 * <p>Intended usage via Scarpet:
 * <pre>
 * effect give @a[tag=!immune] timestop:stun infinite 0 true
 * </pre>
 *
 * <p>The {@code true} flag in the Scarpet command suppresses particles on the
 * client side; the mod itself suppresses the HUD icon via
 * {@link StunEffect#shouldShowIcon()} and drops movement packets via the mixin.
 */
public class TimeStopMod {

    /** Mod ID used as the namespace for all registered assets. */
    public static final String MOD_ID = "timestop";

    /** Shared logger for the mod. */
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /**
     * The registered stun effect instance.
     * This is stored as a static field so that the mixin can reference it
     * directly without performing a registry lookup on every packet.
     */
    public static final class_1291 STUN_EFFECT = new StunEffect();

    /**
     * The Identifier under which the stun effect is registered.
     * Stored as a constant for efficient reuse in the mixin's hot path.
     */
    public static final class_2960 STUN_ID = class_2960.method_60655(MOD_ID, "stun");

    /**
     * Mod initialiser — called by the Fabric loader during bootstrap.
     *
     * <p>Registers the {@code timestop:stun} status effect in the vanilla
     * registry. The effect is {@link StatusEffectCategory#NEUTRAL},
     * completely invisible (no icon, no particles), and non-instant.
     */
    public static void onInitialize() {
        class_2378.method_10230(class_7923.field_41174, STUN_ID, STUN_EFFECT);

        LOGGER.info("TimeStop mod initialized — stun effect registered as {}", STUN_ID);
    }
}
